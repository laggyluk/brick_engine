KMR Editor Icon Set by komorra

License: CC-BY 3.0

Enjoy!